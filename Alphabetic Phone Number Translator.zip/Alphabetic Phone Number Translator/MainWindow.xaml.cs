﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

/// Map numbers to letters:
    /// A, B, C = 2
    /// D, E, F = 3
    /// G, H, I = 4
    /// J, K, L = 5
    /// M, N, O = 6
    /// P, Q, R, S = 7
    /// T, U, V = 8
    /// W, X, Y, Z = 9

/// The focus should be on the individual letters.

///The format of the phone number should be:
    /// XXX-XXX-XXXX

///

namespace Alphabetic_Phone_Number_Translator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string TranslatedNumber = " ";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, RoutedEventArgs e)
        {
            enterNumbersTextBox.Text = " ";
        }
        private static char ConvertToNumber(ref char letter)
        {
            try
            {
                char iki = '2';
                char uc = '3';
                char dort = '4';
                char bes = '5';
                char alti = '6';
                char yedi = '7';
                char sekis = '8';
                char dokus = '9';

                char number = ' ';

                /// Must return the correct number
               if (char.IsLetter(letter))
                {
                    if (letter == 'A' || letter == 'B' || letter == 'C')
                    {
                        number = iki;
                    }

                    else if (letter == 'D' || letter == 'E' || letter == 'F')
                    {
                        number = uc;
                    }

                    else if (letter == 'G' || letter == 'H' || letter == 'I')
                    {
                        number = dort;
                    }

                    else if (letter == 'J' || letter == 'K' || letter == 'L')
                    {
                        number = bes;
                    }

                    else if (letter == 'M' || letter == 'N' || letter == 'O')
                    {
                        number = alti;
                    }

                    else if (letter == 'P' || letter == 'Q' || letter == 'R' || letter == 'S')
                    {
                        number = yedi;
                    }

                    else if (letter == 'T' || letter == 'U' || letter == 'V')
                    {
                        number = sekis;
                    }

                    else if (letter == 'W' || letter == 'X' || letter == 'Y' || letter == 'Z')
                    {
                        number = dokus;
                    }

                    else
                    {
                        number = ' ';
                    }
                }

                else
                {
                    number = ' ';
                }
                

                return number;
            }
            
            catch
            {
                MessageBox.Show("Something went wrong! Try again.");
            }
        }

        private void translateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                /// Get numbers from textbox
                string phoneNumber = enterNumbersTextBox.Text;
                /// Trim numbers
                phoneNumber = phoneNumber.Trim();

                const int LENGTH = 12;
                int i = 0;
                while (i == LENGTH &&
                    char.IsPunctuation(phoneNumber[3]) &&
                    char.IsPunctuation(phoneNumber[7]))
                {
                    phoneNumber = phoneNumber.ToUpper();

                    foreach(char digit in phoneNumber)
                    {
                        if (char.IsDigit(digit) != true)
                        {
                            /// Send to ConvertToNumber. Use BINARY_SEARCH for practice.
                            /// The method should return the number that is associated
                            /// with that particular letter. 

                            char toConvert = digit;

                            if (char.IsLetter(toConvert))
                            {
                                ConvertToNumber(ref toConvert);
                            }

                            TranslatedNumber += Convert.ToString(toConvert);
                            translatedTextBlock.Text = TranslatedNumber;
                        }

                        else
                        {
                            TranslatedNumber += Convert.ToString(digit);
                            translatedTextBlock.Text = TranslatedNumber;
                        }
                    }
                    i++;
                }
            }
            catch
            {
                MessageBox.Show("Try again!");
            }
        }
    }
}
